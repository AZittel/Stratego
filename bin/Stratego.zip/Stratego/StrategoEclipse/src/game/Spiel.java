package game;


import game.gui.BlauSpielfigurLabel;
import game.gui.GUI;
import game.gui.SpielfigurLabel;
import game.spielfeld.BegehbaresFeld;
import game.spielfeld.Feld;
import game.spielfeld.Spieltafel;
import game.spielfiguren.Armee;
import game.spielfiguren.Spielst�ck;
import game.spielfiguren.Spielst�ckTyp;
import java.awt.Color;
import java.awt.Point;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Observer;

public class Spiel {

	public Spieler[] mitspieler = new Spieler[2];
	public Spieltafel spielTafel;

	public SpielZustand spielZustand = SpielZustand.armeeAufbauen;


	public static void main(String[] args) {
		Spiel spiel = new Spiel();
		Armee a1 = new Armee();
		Armee a2 = new Armee();
		Spieler p1 = new Spieler(a1, spiel);
		Spieler p2 = new Spieler(a2, spiel);

		a1.setKontrolleur(p1);
		a2.setKontrolleur(p2);

		spiel.mitspieler[0] = p1;
		spiel.mitspieler[1] = p2;

		spiel.spielTafel = new Spieltafel();
		GUI gui = new GUI(spiel);

		spiel.erstelleComputerArmeeAufstellung(p2, spiel, a2, gui);

		gui.update();



	}

	private void erstelleComputerSpielst�ck(Spielst�ckTyp typ, ArrayList<Integer> numbers, Spieler p2, GUI gui){
		Color color = Color.BLUE;
		for(int i = 0; i < typ.getMaxAmount(); i++){
			BegehbaresFeld feld = null;
			sucheFeld:
			for(int k = 0; k < spielTafel.getSpielTafel().length; k++){
				for(int j = 0; j < spielTafel.getSpielTafel()[k].length; j++){
					if(spielTafel.getSpielTafel()[k][j].number == numbers.get(0)) {
						feld = (BegehbaresFeld) spielTafel.getFeld(new Point(k, j));
						numbers.remove(0);
						for(SpielfigurLabel label : SpielfigurLabel.alleSpielfigurenLabels){
							if(label instanceof BlauSpielfigurLabel && label.typ == typ){
								gui.zellen[k][j].setIcon(label.getIcon(), true, Color.BLUE);
								break;
							}

						}
						break sucheFeld;
					}

				}
			}
			p2.erstelleSpielst�ck(typ, feld, color);
	}

	}

	private void erstelleComputerArmeeAufstellung(Spieler p2, Spiel spiel, Armee a2, GUI gui){
		ArrayList<Integer> numbers = new ArrayList<>();
		for(int i = 0; i < 40; i++){
			numbers.add(i);
		}
		Collections.shuffle(numbers);

		for(Spielst�ckTyp t : Spielst�ckTyp.values()){
			erstelleComputerSpielst�ck(t, numbers, p2, gui);
		}

		for(Spielst�ck st�ck : p2.getArmee().getSpielst�cke()){
			st�ck.setAufgedeckt(false);
		}





	}
	
	public Feld[][] getAufstellbarenBereich() {
		return spielTafel.getSpielTafel();
	}

	public Feld[][] hohleSpielfeld() {
		return spielTafel.getSpielTafel();
	}

	
	
	
	/**
	 * 
	 * @param feld
	 */
	public boolean feldMitFeindlichemSpielst�ckBelegt(Spieler aktuell, Feld feld) {
		
		for(Spieler p : mitspieler) {
			if(p != aktuell) {
				for(Spielst�ck s : p.getArmee().getSpielst�cke()) {
					if(s.position.equals(feld))
						return true;
				}
			}
		}
		
		return false;
	}

	/**
	 * 
	 * @param armee
	 * @param feld
	 */
	public boolean istSpielst�ckVonArmeeAufFeld(Armee armee, Feld feld) {
		for(Spielst�ck s : armee.getSpielst�cke()) {
			if(s.position.equals(feld))
				return true;
		}
		return false;
	}

	/**
	 * 
	 * @param armee
	 * @param feld
	 */
	public Spielst�ck findeSpielst�ckAufFeld(Armee armee, Feld feld) {
		for(Spielst�ck s : armee.getSpielst�cke()) {
			if(s.position.equals(feld))
				return s;
		}
		return null;
	}

}