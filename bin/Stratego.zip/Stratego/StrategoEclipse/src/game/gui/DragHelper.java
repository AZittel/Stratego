package game.gui;

import game.Spiel;
import game.SpielZustand;
import game.Spieler;
import game.spielfeld.BegehbaresFeld;
import game.spielfeld.NichtBegehbaresFeld;
import game.spielfiguren.Spielst�ck;
import java.awt.datatransfer.Transferable;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.TransferHandler;

public class DragHelper extends TransferHandler {


    Spiel spiel;
    GUI gui;
    Spieler p1,p2;


    public DragHelper(GUI gui, Spiel spiel){
        super("icon");
        this.gui = gui;
        this.spiel = spiel;
        p1 = spiel.mitspieler[0];
        p2 = spiel.mitspieler[1];
    }


    @Override
    public boolean importData(JComponent comp, Transferable t) {
    JComponent targetComp = comp;
				if(targetComp instanceof  ZellenLabel) {
        ZellenLabel l = (ZellenLabel) targetComp;

        if (spiel.spielZustand == SpielZustand.armeeAufbauen) {
            p1.best�tigtesFeld = spiel.spielTafel
                .getFeld(l.pos);
//						if(p1.best�tigtesFeld instanceof BegehbaresFeld && !((BegehbaresFeld) p1.best�tigtesFeld).istBelegt() && quelle == null){

            boolean ausPaletteGezogen = gui.quelle == null;
            if(ausPaletteGezogen) {
                System.out.println("erstelle spielst�ck");
                p1.erstelleSpielst�ck(p1.ausgew�hlterSpielst�ckTyp,
                    (BegehbaresFeld) p1.best�tigtesFeld, p1.getArmee().getFarbe());
                gui.update();
                return super.importData(comp, t);
            }else {
                System.out.println("else switch icons");
                boolean zielFeldIstBelegt = (p1.best�tigtesFeld instanceof BegehbaresFeld && ((BegehbaresFeld) p1.best�tigtesFeld).istBelegt());

                //zellen[l.pos.x][l.pos.y].setIcon(((ZellenLabel) quelle).getIcon());

                BegehbaresFeld f = (BegehbaresFeld)l.feld;
                BegehbaresFeld q = (BegehbaresFeld)gui.quelle.feld;
                System.out.println("Ziel Icon?: " + l.getIcon());
                System.out.println("Quelle Icon?: " + gui.quelle.getIcon());

                Spielst�ck neu = p1.getArmee().getSpielst�ckVonSpieltafel(gui.quelle.pos);
                if(!zielFeldIstBelegt) {
                    gui.zellen[l.pos.x][l.pos.y].setIcon((gui.quelle).getIcon());
                    gui.zellen[gui.quelle.pos.x][gui.quelle.pos.y].setIcon(null);
                    f.setBelegt(true);
                    q.setBelegt(false);
                }
                else
                // Switch
                {
                    Spielst�ck alt = p1.getArmee().getSpielst�ckVonSpieltafel(l.pos);


                    Icon tmp = gui.quelle.getIcon();
                    gui.zellen[gui.quelle.pos.x][gui.quelle.pos.y].setIcon((l).getIcon());
                    gui.zellen[l.pos.x][l.pos.y].setIcon(tmp);
                    alt.setPosition((BegehbaresFeld)gui.quelle.feld);

                }
                neu.setPosition((BegehbaresFeld)l.feld);

                gui.quelle = null;
                gui.update();
                return super.importData(comp, t);
            }

        }
    }
				return super.importData(comp, t);
}

    /*
    Hier wird �berpr�ft ob Drag & Drop auf dem Ziel Component erlaubt ist
     */
    @Override
    public boolean canImport(TransferHandler.TransferSupport support) {

        JComponent targetComp = (JComponent)support.getComponent();

        if(targetComp instanceof BlauSpielfigurLabel){
            return false;
        }
        else if(targetComp instanceof RotSpielfigurLabel){
            return false;
        }

        if(targetComp instanceof  ZellenLabel){
            if (spiel.spielZustand == SpielZustand.armeeAufbauen) {
                ZellenLabel l = (ZellenLabel) targetComp;
                p1.best�tigtesFeld = spiel.spielTafel
                    .getFeld(l.pos);
                boolean ausPaletteGezogen = gui.quelle == null;
                boolean zielFeldNichtBegehbar = p1.best�tigtesFeld instanceof NichtBegehbaresFeld;
                boolean zielFeldNichtImAufstellungsBereich = p1.best�tigtesFeld.number < 60;
                boolean zielFeldIstBelegt = (p1.best�tigtesFeld instanceof BegehbaresFeld && ((BegehbaresFeld) p1.best�tigtesFeld).istBelegt());
                if(zielFeldNichtBegehbar  || zielFeldNichtImAufstellungsBereich || (zielFeldIstBelegt && ausPaletteGezogen)){
                    return false;
                }

            }
            return true;
        }


        return false;
    }




}
