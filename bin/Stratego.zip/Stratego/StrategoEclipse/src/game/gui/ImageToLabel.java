package game.gui;

import game.SpielSeite;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.TransferHandler;

public class ImageToLabel extends JLabel {

    SpielSeite seite;

    public ImageToLabel(String image, SpielSeite seite) {
        super();

        this.seite = seite;
        // set up the image
        ImageIcon imageIcon = new ImageIcon(image);
        this.setSize(imageIcon.getIconWidth(), imageIcon.getIconHeight());
        this.setIcon(imageIcon);



    }
}
