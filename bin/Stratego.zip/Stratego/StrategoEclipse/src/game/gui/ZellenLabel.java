package game.gui;

import game.spielfeld.BegehbaresFeld;
import game.spielfeld.Feld;
import game.spielfiguren.Spielst�ckTyp;
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.TransferHandler;

public class ZellenLabel extends JLabel {

   public Point pos;
   public int nr;
   public Feld feld;
   public Spielst�ckTyp typ;
   public static ImageIcon verdecktIconRot = new ImageIcon("roteArmee/verdeckt.png");
   public static ImageIcon verdecktIconBlau = new ImageIcon("blaueArmee/verdeckt.png");
   public static ArrayList<ZellenLabel> alleZellen = new ArrayList<>();


    public ZellenLabel(Point pos, int nr, Feld feld){
        this.pos = pos;
        this.nr = nr;
        this.feld = feld;
        this.setTransferHandler(new TransferHandler("icon"));
        alleZellen.add(this);



    }



    public void setIcon(Icon i, boolean aufgedeckt, Color spielerFarbe){
        if(!aufgedeckt && spielerFarbe == Color.RED){
            super.setIcon(verdecktIconRot);
        }
        else  if(!aufgedeckt && spielerFarbe == Color.BLUE){
            super.setIcon(verdecktIconBlau);
        }
        else
        super.setIcon(i);
    }
}
