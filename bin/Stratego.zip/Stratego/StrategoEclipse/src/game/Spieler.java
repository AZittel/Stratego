package game;

import game.spielfeld.BegehbaresFeld;
import game.spielfeld.Feld;
import game.spielfiguren.Armee;
import game.spielfiguren.BeweglichesSpielst�ck;
import game.spielfiguren.Spielst�ck;
import game.spielfiguren.Spielst�ckTyp;
import java.awt.Color;
import java.util.ArrayList;

public class Spieler{

	public Spiel spielLeitung;
	Armee armee;
	public ArrayList<Spielst�ck> aufgestellteSpielst�cke = new ArrayList<Spielst�ck>();
	public ArrayList<BeweglichesSpielst�ck> beweglichenSpielst�cke = new ArrayList<BeweglichesSpielst�ck>() ;

	public Spielst�ckTyp ausgew�hlterSpielst�ckTyp;
	public Feld best�tigtesFeld;
	public Feld ausgew�hltesFeld;

	
	public Spieler(Armee armee, Spiel leitung) {
		this.armee = armee;
		this.spielLeitung = leitung;
	}
	

	
	public void erstelleSpielst�ck(Spielst�ckTyp typ, BegehbaresFeld feld, Color farbe) {


		switch(typ) {
			case Spion:
				armee.new Spion(feld, farbe, this, typ);
				break;
			case Aufkl�rer:
				armee.new Aufkl�rer(feld, farbe, this, typ);
				break;
			case Mineur:
				armee.new Mineur(feld, farbe, this, typ);
				break;
			case Unteroffizier:
				armee.new Unteroffizier(feld, farbe, this, typ);
				break;
			case Leutnant:
				armee.new Leutnant(feld, farbe, this, typ);
				break;
			case Hauptmann:
				armee.new Hauptmann(feld, farbe, this, typ);
				break;
			case Major:
				armee.new Major(feld, farbe, this, typ);
				break;
			case Oberst:
				armee.new Oberst(feld, farbe, this, typ);
				break;
			case General:
				armee.new General(feld, farbe, this, typ);
				break;
			case Feldmarschall:
				armee.new Feldmarschall(feld, farbe, this, typ);
				break;
			case Fahne:
				armee.new Fahne(feld, farbe, this, typ);
				break;
			case Bombe:
				armee.new Bombe(feld, farbe, this, typ);
				break;
		
		
		}


	}

	public Spielst�ckTyp spielst�ckTypAusw�hlen() {
		// TODO - implement Spieler.spielst�ckAufstellen
		throw new UnsupportedOperationException();
	}

	public BegehbaresFeld feldAusw�hlen() {
		// TODO - implement Spieler.spielst�ckAufstellen
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param feld
	 */
	public boolean feldBelegt(BegehbaresFeld feld) {
		return feld.istBelegt();
	}

	public void zugDurchf�hren() {
		// TODO - implement Spieler.zugDurchf�hren
		throw new UnsupportedOperationException();
	}



	public BeweglichesSpielst�ck beweglichesSpielst�ckAusw�hlen() {
		// TODO - implement Spieler.beweglichesSpielst�ckAusw�hlen
		throw new UnsupportedOperationException();
	}

	public Feld zielFeldAusw�hlen() {
		// TODO - implement Spieler.zielFeldAusw�hlen
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param spielst�ck
	 */
	public boolean beweglichesSpielst�ckKannFeldErreichen(BeweglichesSpielst�ck spielst�ck) {
		// TODO - implement Spieler.beweglichesSpielst�ckKannFeldErreichen
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param feld
	 */
	public boolean feldNichtMitEigenemSpielst�ckBelegt(Feld feld) {
		for(Spielst�ck s : armee.getSpielst�cke()) {
			if(s.position.equals(feld))
				return false;
		}
		return true;
	}

	/**
	 * Kein Feindkontakt
	 * @param spielst�ck
	 * @param feld
	 */
	public void spielst�ckAufFeldBewegen(BeweglichesSpielst�ck spielst�ck, BegehbaresFeld feld) {
			spielst�ck.position.setBelegt(false);
			spielst�ck.position = feld;
			feld.setBelegt(true);
	}

	/**
	 * Mit Feindkontakt
	 * @param spielst�ck
	 * @param feld
	 */
	public void platziereSpielst�ckAufFeld(BeweglichesSpielst�ck spielst�ck, BegehbaresFeld feld) {
		spielst�ck.position.setBelegt(false);
		spielst�ck.position = feld;
		feld.setBelegt(true);
	}

	/**
	 * 
	 * @param erstesSpielst�ck
	 * @param zweitesSpielst�ck
	 */
	public Spielst�ck auseinandersetzungPr�fen(BeweglichesSpielst�ck erstesSpielst�ck, Spielst�ck zweitesSpielst�ck) {
		// TODO - implement Spieler.auseinandersetzungPr�fen
		throw new UnsupportedOperationException();
	}

	public Armee getArmee() {
		return this.armee;
	}

}