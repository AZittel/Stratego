package game.spielfiguren;

import game.Spieler;
import game.spielfeld.BegehbaresFeld;
import java.awt.Color;

public class BeweglichesSpielst�ck extends Spielst�ck {

	protected BeweglichesSpielst�ck(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
		super(position, farbe, besitzer, typ);
		besitzer.beweglichenSpielst�cke.add(this);
	}



}