package game.spielfiguren;


public enum Spielst�ckTyp {
	Spion(1),
	Aufkl�rer(8),
	Mineur(5),
	Unteroffizier(4),
	Leutnant(4),
	Hauptmann(4),
	Major(3),
	Oberst(2),
	General(1),
	Feldmarschall(1),
	Fahne(1),
	Bombe(6);

	private int maxAmount;

	/**
	 * 
	 * @param maxAmount
	 */
	private Spielst�ckTyp(int maxAmount) {
		this.maxAmount = maxAmount;
	}

	public int getMaxAmount() {
		return maxAmount;
	}

}