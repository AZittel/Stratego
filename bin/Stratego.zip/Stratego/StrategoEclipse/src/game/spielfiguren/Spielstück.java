package game.spielfiguren;

import game.Spieler;
import game.spielfeld.BegehbaresFeld;
import game.spielfiguren.Spielst�ckTyp;
import java.awt.Color;

public abstract class Spielst�ck {

	public Spieler besitzer;

	private  Spielst�ckTyp typ;
	private  Color farbe;

	public BegehbaresFeld position;
	private boolean aufgedeckt;

	protected Spielst�ck(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
		this.aufgedeckt = false;
		this.position = position;
		this.farbe = farbe;
		this.besitzer = besitzer;
		this.typ = typ;
		besitzer.getArmee().spielst�cke.add(this);
		besitzer.aufgestellteSpielst�cke.add(this);

		position.setBesetzer(this);
		position.setBelegt(true);
	}
	
	/**
	 * 
	 * @param aufgedeckt
	 */
	public void setAufgedeckt(boolean aufgedeckt) {
		this.aufgedeckt = aufgedeckt;
	}

	
	public Spielst�ckTyp getTyp() {
		return typ;
	}

	public BegehbaresFeld getPosition() {
		return position;
	}

	public void setPosition(BegehbaresFeld position) {
		this.position = position;
	}

	public boolean getAufgedeckt() {
		return this.aufgedeckt;
	}

}