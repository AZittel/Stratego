package game;

public enum SpielZustand {
    armeeAufbauen,
    zugDurchf�hren
}
