package game.spielfiguren;

import game.Spieler;
import game.spielfeld.BegehbaresFeld;
import java.awt.Color;
import java.util.ArrayList;

public class BeweglichesSpielst�ck extends Spielst�ck {

	public ArrayList<BegehbaresFeld> bewegungsRaum = new ArrayList<>();

	protected BeweglichesSpielst�ck(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
		super(position, farbe, besitzer, typ);
		besitzer.beweglichenSpielst�cke.add(this);
	}



}