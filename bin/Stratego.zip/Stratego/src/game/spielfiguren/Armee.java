package game.spielfiguren;

import game.Spieler;
import game.spielfeld.BegehbaresFeld;
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Armee {



	Spieler kontrolleur;
	private Color farbe;
	public ArrayList<Spielst�ck> spielst�cke = new ArrayList<>();
	BeweglichesSpielst�ck[] beweglicheSpielst�cke;
	UnbeweglichesSpielst�ck[] unbeweglicheSpielst�cke;


	public Armee(Color c){
		this.farbe = c;
	}

	public void l�scheSpielst�ck(Spielst�ck s){

		s.position.setBelegt(false);
		s.position.setBesetzer(null);
		spielst�cke.remove(s);
	}


	/**
	 *
	 */
	public boolean spielst�ckNochAufzustellen(Spielst�ckTyp typ) {
		return anzahlVonSpielst�ckTypMaximumErreicht(typ);
	}

	/**
	 *
	 */
	public boolean anzahlVonSpielst�ckTypMaximumErreicht(Spielst�ckTyp typ) {
		 if(getAnzahlSpielst�ckInArmee(typ) < typ.getMaxAmount())
			return true;
		else
			return false;

	}

	public int getAnzahlSpielst�ckInArmee(Spielst�ckTyp typ){
		int count = 0;
		for (Spielst�ck s : spielst�cke) {
			if (s.getTyp().toString() == typ.toString())
				count++;
		}

		return count;
	}

	public Spielst�ck getSpielst�ckVonSpieltafel(Point position){
		BegehbaresFeld feld = (BegehbaresFeld)kontrolleur.spielLeitung.spielTafel.getFeld(position);
		if(feld.istBelegt()){
			for(Spielst�ck figur : spielst�cke){
				if(figur.position.position.equals(position)){
					return figur;
				}
			}
		}

		return null;


	}

	public void entferneSpielst�ck(Spielst�ck s){
		spielst�cke.remove(s);
	}

	public ArrayList<Spielst�ck> getSpielst�cke() {
		return spielst�cke;
	}

	public Color getFarbe() {
		return farbe;
	}



	

	public class Spion extends BeweglichesSpielst�ck{
		public Spion(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer, typ);
		}
	}
	
	

	public class Leutnant extends BeweglichesSpielst�ck{

		public Leutnant(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer, typ);
			// TODO Auto-generated constructor stub
		}
		
	}


	public class Unteroffizier extends BeweglichesSpielst�ck{

		public Unteroffizier(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer, typ);
			// TODO Auto-generated constructor stub
		}
		
	}


	public class Major extends BeweglichesSpielst�ck{

		public Major(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}

	}


	public class General extends BeweglichesSpielst�ck{

		public General(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
		
	}


	public class Oberst extends BeweglichesSpielst�ck{

		public Oberst(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Bombe extends UnbeweglichesSpielst�ck{

		public Bombe(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Aufkl�rer extends BeweglichesSpielst�ck{

		public Aufkl�rer(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Mineur extends BeweglichesSpielst�ck{

		public Mineur(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Fahne extends UnbeweglichesSpielst�ck{

		public Fahne(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Feldmarschall extends BeweglichesSpielst�ck{

		public Feldmarschall(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}


	public class Hauptmann extends BeweglichesSpielst�ck{

		public Hauptmann(BegehbaresFeld position, Color farbe, Spieler besitzer, Spielst�ckTyp typ) {
			super(position, farbe, besitzer,typ);
			// TODO Auto-generated constructor stub
		}
	}
	public Spieler getKontrolleur() {
		return kontrolleur;
	}

	public void setKontrolleur(Spieler kontrolleur) {
		this.kontrolleur = kontrolleur;
	}
}