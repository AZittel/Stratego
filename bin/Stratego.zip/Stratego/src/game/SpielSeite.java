package game;

public enum SpielSeite {
    BLAU,
    ROT;
}
