package game.gui;

import game.SpielSeite;
import game.spielfiguren.Spielst�ckTyp;

public class RotSpielfigurLabel extends SpielfigurLabel {

    public RotSpielfigurLabel(String image, SpielSeite seite, Spielst�ckTyp typ) {
        super(image, seite, typ);

    }
}
