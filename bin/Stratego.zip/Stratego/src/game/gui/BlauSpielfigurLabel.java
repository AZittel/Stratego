package game.gui;

import game.SpielSeite;
import game.spielfiguren.Spielst�ckTyp;

public class BlauSpielfigurLabel extends SpielfigurLabel
{

    public BlauSpielfigurLabel(String image, SpielSeite seite, Spielst�ckTyp typ) {
        super(image, seite, typ);

    }
}
