package game;

public enum SpielZustand {
    armeeAufbauen,
    spielerAmZug,
    computerAmZug,
    spielBeendet;
}
