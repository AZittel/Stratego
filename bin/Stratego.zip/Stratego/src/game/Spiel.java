package game;


import game.gui.GUI;
import game.gui.SpielfigurLabel;
import game.spielfeld.BegehbaresFeld;
import game.spielfeld.Feld;
import game.spielfeld.Spieltafel;
import game.spielfiguren.Armee;
import game.spielfiguren.Armee.Aufkl�rer;
import game.spielfiguren.Armee.Bombe;
import game.spielfiguren.Armee.Feldmarschall;
import game.spielfiguren.Armee.Mineur;
import game.spielfiguren.Armee.Spion;
import game.spielfiguren.BeweglichesSpielst�ck;
import game.spielfiguren.Spielst�ck;
import game.spielfiguren.Spielst�ckTyp;
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;

public class Spiel {

  public Spieler[] mitspieler = new Spieler[2];
  public Spieler computer;
  public Spieltafel spielTafel;
  public static GUI gui;
  public SpielZustand spielZustand = SpielZustand.armeeAufbauen;
  public int zugZaehler = 1;

  public static void main(String[] args) {

    Spiel spiel = new Spiel();
    Armee a1 = new Armee(Color.RED);
    Armee a2 = new Armee(Color.BLUE);
    Spieler p1 = new Spieler(a1, spiel, "Rot");
    Spieler p2 = new Spieler(a2, spiel, "Blau");

    a1.setKontrolleur(p1);
    a2.setKontrolleur(p2);

    spiel.mitspieler[0] = p1;
    spiel.mitspieler[1] = p2;
    spiel.computer = spiel.mitspieler[1];
    spiel.spielTafel = new Spieltafel();
    gui = new GUI(spiel);

    spiel.erstelleComputerArmeeAufstellung(p2, spiel, a2, gui);

    gui.update();


  }

  /**
   * Platziert ein Spielst�ck auf ein freies feld
   */
  public void spielst�ckAufFreiesFeldBewegen(Spielst�ck s, BegehbaresFeld zielFeld) {
    if (!zielFeld.istBelegt()) {
      BegehbaresFeld vonFeld = s.getPosition();

      vonFeld.setBesetzer(null);
      vonFeld.setBelegt(false);

      s.setPosition(zielFeld);
      zielFeld.setBelegt(true);
      zielFeld.setBesetzer(s);
    }
  }

  public void computerSpielzugDurchf�hren() {
    try {
      Thread.sleep(500);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    ArrayList<Integer> numb = erstelleZuf�lligeListe(0, computer.armee.spielst�cke.size());

    for (int i = 0; i < numb.size(); i++) {
      Spielst�ck angreifer = computer.getArmee().spielst�cke.get(numb.get(0));
      numb.remove(0);

      if (angreifer instanceof BeweglichesSpielst�ck) {
        gui.quelle = gui.getZellenLabel(angreifer.position.position);
        gui.spielst�ckAufFeld = (BeweglichesSpielst�ck) angreifer;
        ArrayList<BegehbaresFeld> bewegungsBereich = ermittleBewegungsBereich((BeweglichesSpielst�ck) angreifer);
        if (bewegungsBereich.size() > 0) {
          int rndNr = (int) Math.abs((Math.random() * (bewegungsBereich.size()-1)));


          BegehbaresFeld zielFeld = bewegungsBereich.get(rndNr);

          gui.zugDurchf�hren((BeweglichesSpielst�ck) angreifer, zielFeld.position);
          spielZustand = SpielZustand.spielerAmZug;
          gui.informationsFeld.append("Zug: " + ++zugZaehler + " beginnt!\n");
          break;
        }


      }


    }


  }


  public ArrayList<BegehbaresFeld> ermittleBewegungsBereich(BeweglichesSpielst�ck spielst�ck) {
    ArrayList<BegehbaresFeld> bewegungsFelder = new ArrayList<>();

    if (!(spielst�ck instanceof Aufkl�rer)) {
      // Kein Aufkl�rer
      if (pr�feEinfacheDirektionaleBewegung((int) spielst�ck.getPosition().position.getX() - 1, (int) spielst�ck.getPosition().position.getY(), spielst�ck))
        bewegungsFelder.add((BegehbaresFeld) spielTafel.getFeld(new Point((int) spielst�ck.getPosition().position.getX() - 1, (int) spielst�ck.getPosition().position.getY())));
      if (pr�feEinfacheDirektionaleBewegung((int) spielst�ck.getPosition().position.getX(), (int) spielst�ck.getPosition().position.getY() - 1, spielst�ck))
        bewegungsFelder.add((BegehbaresFeld) spielTafel.getFeld(new Point((int) spielst�ck.getPosition().position.getX(), (int) spielst�ck.getPosition().position.getY() - 1)));
      if (pr�feEinfacheDirektionaleBewegung((int) spielst�ck.getPosition().position.getX(), (int) spielst�ck.getPosition().position.getY() + 1, spielst�ck))
        bewegungsFelder.add((BegehbaresFeld) spielTafel.getFeld(new Point((int) spielst�ck.getPosition().position.getX(), (int) spielst�ck.getPosition().position.getY() + 1)));
      if (pr�feEinfacheDirektionaleBewegung((int) spielst�ck.getPosition().position.getX() + 1, (int) spielst�ck.getPosition().position.getY(), spielst�ck))
        bewegungsFelder.add((BegehbaresFeld) spielTafel.getFeld(new Point((int) spielst�ck.getPosition().position.getX() + 1, (int) spielst�ck.getPosition().position.getY())));

    } else {
      //Aufkl�rer
      int x = (int) spielst�ck.getPosition().position.getX();
      int y = (int) spielst�ck.getPosition().position.getY();
      Point pos = new Point(x, y - 1);
      //Norden
      while (true) {
        if (spielTafel.getBegehbaresFeld(pos) == null || (pos.y < y - 1 && spielTafel.getBegehbaresFeld(pos).istBelegt())
          || istSpielst�ckVonArmeeAufFeld(spielst�ck.besitzer.getArmee(), spielTafel.getFeld(pos))) {
          break;
        }
        bewegungsFelder.add(spielTafel.getBegehbaresFeld(pos));
        pos.y--;
      }

      //Osten
      pos.x = x + 1;
      pos.y = y;
      while (true) {
        if (spielTafel.getBegehbaresFeld(pos) == null || (pos.x > x + 1 && spielTafel.getBegehbaresFeld(pos).istBelegt())
          || istSpielst�ckVonArmeeAufFeld(spielst�ck.besitzer.getArmee(), spielTafel.getFeld(pos))) {
          break;
        }
        bewegungsFelder.add(spielTafel.getBegehbaresFeld(pos));
        pos.x++;
      }
      //S�den
      pos.x = x;
      pos.y = y + 1;
      while (true) {
        if (spielTafel.getBegehbaresFeld(pos) == null || (pos.y > y + 1 && spielTafel.getBegehbaresFeld(pos).istBelegt())
          || istSpielst�ckVonArmeeAufFeld(spielst�ck.besitzer.getArmee(), spielTafel.getFeld(pos))) {
          break;
        }
        bewegungsFelder.add(spielTafel.getBegehbaresFeld(pos));
        pos.y++;
      }
      //Westen
      pos.x = x - 1;
      pos.y = y;
      while (true) {
        if (spielTafel.getBegehbaresFeld(pos) == null || (pos.x < x - 1 && spielTafel.getBegehbaresFeld(pos).istBelegt())
          || istSpielst�ckVonArmeeAufFeld(spielst�ck.besitzer.getArmee(), spielTafel.getFeld(pos))) {
          break;
        }
        bewegungsFelder.add(spielTafel.getBegehbaresFeld(pos));
        pos.x--;
      }


    }


    return bewegungsFelder;
  }

  public boolean feldImBewegungsRaum(BegehbaresFeld f, BeweglichesSpielst�ck s) {
    for (BegehbaresFeld bFeld : s.bewegungsRaum) {
      if (bFeld == f)
        return true;
    }
    return false;
  }


  public boolean pr�feEinfacheDirektionaleBewegung(int x, int y, BeweglichesSpielst�ck s) {

    Feld feld = spielTafel.getFeld(new Point(x, y));
    if (feld instanceof BegehbaresFeld &&
      (!((BegehbaresFeld) feld).istBelegt() ||
        feldMitFeindlichemSpielst�ckBelegt(s.besitzer, feld))) {
      return true;
    }
    return false;
  }

  private void erstelleZufallSpielst�ck(Spielst�ckTyp typ, ArrayList<Integer> numbers, Spieler p, GUI gui) {
    Color color = p.getArmee().getFarbe();
    for (int i = 0; i < typ.getMaxAmount(); i++) {
      BegehbaresFeld feld = null;
      int startK = color != Color.RED ? 0 : 5;
      sucheFeld:
      for (int k = startK; k < spielTafel.getSpielTafel().length; k++) {
        for (int j = 0; j < spielTafel.getSpielTafel()[k].length; j++) {
          if (spielTafel.getSpielTafel()[k][j].number == numbers.get(0)) {
            feld = (BegehbaresFeld) spielTafel.getFeld(new Point(k, j));
            numbers.remove(0);
            for (SpielfigurLabel label : SpielfigurLabel.alleSpielfigurenLabels) {
              if (color == Color.BLUE && label.typ == typ) {
                gui.zellen[k][j].setIcon(SpielfigurLabel.getIconFromType(typ,color), false, color);
                break;
              } else if (color == Color.RED && label.typ == typ) {
                gui.zellen[k][j].setIcon(SpielfigurLabel.getIconFromType(typ,color), true, color);
                break;
              }

            }
            break sucheFeld;
          }

        }
      }
      p.erstelleSpielst�ck(typ, feld, color);
    }

  }

  public boolean hatSpielerNochBeweglicheSpielst�cke(Spieler p){
    for(Spielst�ck s : p.getArmee().spielst�cke){
      if(s instanceof BeweglichesSpielst�ck)
        return true;
    }
    return false;
  }

  private void erstelleComputerArmeeAufstellung(Spieler p2, Spiel spiel, Armee a2, GUI gui) {
    ArrayList<Integer> numbers = erstelleZuf�lligeListe(0, 40);
    for (Spielst�ckTyp t : Spielst�ckTyp.values()) {
      erstelleZufallSpielst�ck(t, numbers, p2, gui);
    }

    for (Spielst�ck st�ck : p2.getArmee().getSpielst�cke()) {
      //st�ck.setAufgedeckt(false);
    }


  }


  public void erstelleZuf�lligeAufstellung() {
    ArrayList<Integer> numbers = erstelleZuf�lligeListe(60, 100);
    Spieler p1 = mitspieler[0];

    for (int i = 0; i < p1.getArmee().getSpielst�cke().size(); i++) {
      p1.getArmee().l�scheSpielst�ck(p1.getArmee().getSpielst�cke().remove(i));
      i--;
    }

    for (Spielst�ckTyp t : Spielst�ckTyp.values()) {
      erstelleZufallSpielst�ck(t, numbers, p1, gui);
    }

  }


  public void starteSpiel() {
    gui.informationsFeld.append("Zug: " + zugZaehler + " beginnt!\n");
    spielZustand = SpielZustand.spielerAmZug;

  }


  private ArrayList<Integer> erstelleZuf�lligeListe(int von, int bis) {
    ArrayList<Integer> numbers = new ArrayList<>();
    for (int i = von; i < bis; i++) {
      numbers.add(i);
    }
    Collections.shuffle(numbers);
    return numbers;
  }

  public Feld[][] getAufstellbarenBereich() {
    return spielTafel.getSpielTafel();
  }

  public Feld[][] hohleSpielfeld() {
    return spielTafel.getSpielTafel();
  }


  /**
   * Vertauscht die Position zweier Spielst�cke
   */
  public void spielst�ckeVetauschen(Spielst�ck a, Spielst�ck b) {
    BegehbaresFeld tmp = a.getPosition();
    a.position.setBesetzer(b);
    a.setPosition(b.position);
    b.position.setBesetzer(a);
    b.setPosition(tmp);
  }

  /**
   *
   */
  public boolean feldMitFeindlichemSpielst�ckBelegt(Spieler aktuell, Feld feld) {

    for (Spieler p : mitspieler) {
      if (p != aktuell) {
        for (Spielst�ck s : p.getArmee().getSpielst�cke()) {
          if (s.position.equals(feld))
            return true;
        }
      }
    }

    return false;
  }

  /**
   *
   */
  public boolean istSpielst�ckVonArmeeAufFeld(Armee armee, Feld feld) {
    for (Spielst�ck s : armee.getSpielst�cke()) {
      if (s.position.equals(feld))
        return true;
    }
    return false;
  }

  /**
   *
   */
  public Spielst�ck findeSpielst�ckAufFeld(Armee armee, Feld feld) {
    for (Spielst�ck s : armee.getSpielst�cke()) {
      if (s.position.equals(feld))
        return s;
    }
    return null;
  }

  /**
   * Pr�ft welches Spielst�ck den Schlagabtausch gewinnt
   *
   * @return Gibt das Sieger Spielst�ck zur�ck, falls es keinen Sieger gibt wird null zur�ckgegeben
   */
  public Spielst�ck ermittelGewinner(BeweglichesSpielst�ck angreifer, Spielst�ck verteidiger) {

    if (angreifer instanceof Spion && verteidiger instanceof Feldmarschall) {
      return angreifer;
    } else if (angreifer instanceof Mineur && verteidiger instanceof Bombe) {
      return angreifer;
    }
    if (verteidiger instanceof Bombe) {
      return null;
    }

    if (angreifer.getTyp().getWertigkeit() > verteidiger.getTyp().getWertigkeit()) {
      return angreifer;
    } else if (angreifer.getTyp().getWertigkeit() < verteidiger.getTyp().getWertigkeit()) {
      return verteidiger;
    } else
      return null;

  }

  public void feldAufr�umen(Feld f) {
    if (f instanceof BegehbaresFeld) {
      ((BegehbaresFeld) f).setBesetzer(null);
      ((BegehbaresFeld) f).setBelegt(false);
    }
  }
}