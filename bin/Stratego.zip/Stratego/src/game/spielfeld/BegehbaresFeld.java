package game.spielfeld;


import game.spielfiguren.Spielst�ck;
import java.awt.Point;

public class BegehbaresFeld extends Feld {

	private Spielst�ck besetzer;
	private boolean belegt;
	public boolean aufstellungsFeld;

	public BegehbaresFeld(Point position, int nr) {
		super(position, nr);
		if(nr >= 60)
			aufstellungsFeld = true;
	}

	public boolean istBelegt() {
		return belegt;
	}

	public void setBelegt(boolean b) {
		this.belegt = b;
	}

	public Spielst�ck getBesetzer() {
		return besetzer;
	}

	public void setBesetzer(Spielst�ck besetzer) {
		this.besetzer = besetzer;
	}
}