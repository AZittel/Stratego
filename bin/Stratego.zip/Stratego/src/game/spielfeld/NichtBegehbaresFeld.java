package game.spielfeld;

import java.awt.Point;

public class NichtBegehbaresFeld extends Feld {

    protected NichtBegehbaresFeld(Point position, int nr) {
        super(position, nr);

    }
}